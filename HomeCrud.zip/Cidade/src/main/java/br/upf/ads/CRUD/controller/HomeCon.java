package br.upf.ads.CRUD.controller;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class HomeCon implements java.io.Serializable{
	 
	public HomeCon() {
		super();
	}
	
}
